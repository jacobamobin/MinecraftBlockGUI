import javax.swing.*;
import java.util.ArrayList;

public class Main {
    static final int FRAME_WIDTH = 1080;
    static final int FRAME_HEIGHT = 720;
    static final int FRAME_RATE = 60; // Frames per second (adjust as needed)

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainMenuGUI::mainMenu);
    }
}
