class blockFamilial{
   //fields
   String familyName;
   int familySize;
   boolean recolour;
   String conditionals;
   int[] familyPaths;
   
   public blockFamilial(String familyName, int familySize, boolean recolour, String conditionals, int[] familyPaths){
      this.familyName = familyName;
      this.familySize = familySize;
      this.recolour = recolour;
      this.conditionals = conditionals;
      this.familyPaths = familyPaths;
   }
}